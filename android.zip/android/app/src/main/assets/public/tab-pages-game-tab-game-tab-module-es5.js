function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-pages-game-tab-game-tab-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/game-tab/game-tab.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/game-tab/game-tab.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTabPagesGameTabGameTabPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Game\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Game</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <app-explore-container name=\"Game page\"></app-explore-container>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/game-tab/game-tab-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/tab-pages/game-tab/game-tab-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: GameTabPageRoutingModule */

  /***/
  function srcAppPagesTabPagesGameTabGameTabRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GameTabPageRoutingModule", function () {
      return GameTabPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _game_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./game-tab.page */
    "./src/app/pages/tab-pages/game-tab/game-tab.page.ts");

    var routes = [{
      path: '',
      component: _game_tab_page__WEBPACK_IMPORTED_MODULE_3__["GameTabPage"]
    }];

    var GameTabPageRoutingModule = function GameTabPageRoutingModule() {
      _classCallCheck(this, GameTabPageRoutingModule);
    };

    GameTabPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], GameTabPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/game-tab/game-tab.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/tab-pages/game-tab/game-tab.module.ts ***!
    \*************************************************************/

  /*! exports provided: GameTabPageModule */

  /***/
  function srcAppPagesTabPagesGameTabGameTabModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GameTabPageModule", function () {
      return GameTabPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _game_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./game-tab-routing.module */
    "./src/app/pages/tab-pages/game-tab/game-tab-routing.module.ts");
    /* harmony import */


    var _game_tab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./game-tab.page */
    "./src/app/pages/tab-pages/game-tab/game-tab.page.ts");

    var GameTabPageModule = function GameTabPageModule() {
      _classCallCheck(this, GameTabPageModule);
    };

    GameTabPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _game_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__["GameTabPageRoutingModule"]],
      declarations: [_game_tab_page__WEBPACK_IMPORTED_MODULE_6__["GameTabPage"]]
    })], GameTabPageModule);
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/game-tab/game-tab.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pages/tab-pages/game-tab/game-tab.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTabPagesGameTabGameTabPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3RhYi1wYWdlcy9nYW1lLXRhYi9nYW1lLXRhYi5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/game-tab/game-tab.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/tab-pages/game-tab/game-tab.page.ts ***!
    \***********************************************************/

  /*! exports provided: GameTabPage */

  /***/
  function srcAppPagesTabPagesGameTabGameTabPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GameTabPage", function () {
      return GameTabPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var GameTabPage = /*#__PURE__*/function () {
      function GameTabPage() {
        _classCallCheck(this, GameTabPage);
      }

      _createClass(GameTabPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return GameTabPage;
    }();

    GameTabPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-game-tab',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./game-tab.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/game-tab/game-tab.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./game-tab.page.scss */
      "./src/app/pages/tab-pages/game-tab/game-tab.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], GameTabPage);
    /***/
  }
}]);
//# sourceMappingURL=tab-pages-game-tab-game-tab-module-es5.js.map