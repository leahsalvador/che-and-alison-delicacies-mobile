function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-pages-home-tab-home-tab-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/home-tab/home-tab.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/home-tab/home-tab.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTabPagesHomeTabHomeTabPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!--<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Home\n    </ion-title>\n  </ion-toolbar>\n</ion-header>-->\n\n<ion-content padding [fullscreen]=\"true\">\n  <ion-grid>\n    \n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item lines=\"none\">\n          <ion-img src=\"assets/icon/ROS.png\" id=\"home-logo\"></ion-img>\n        </ion-item>\n        <ion-text color=\"light\" class=\"ion-no-margin\">\n          <p id=\"home-top-text\" class=\"ion-text-center\">Colorful <span class=\"ion-text-uppercase\">protection</span> for your \n              <span class=\"ion-text-uppercase home-span-color\">home</span></p>\n        </ion-text>\n        <ion-searchbar color=\"light\"></ion-searchbar>\n      </ion-col>\n    </ion-row>\n    <ion-row> \n      <ion-col id=\"product-catalog\" (click)=\"openProductCatalog()\" \n          class=\"ion-padding-start ion-padding-end \" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"file-tray-full-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Product<br/>Catalog</h3>\n          </ion-text>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-item>\n      </ion-col>\n      <ion-col id=\"choose-paint\" (click)=\"openChoosePaint()\" \n          class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"color-fill-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Choose<br/>Paint</h3>\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-text>\n        </ion-item>\n      </ion-col>\n      <ion-col id=\"color-collections\" (click)=\"openColorCollections()\" \n          class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"albums-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Color<br/>Collections</h3>\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-text>\n        </ion-item>\n      </ion-col>\n      <ion-col id=\"designer-scheme\" (click)=\"openDesignerScheme()\" \n          class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"pencil-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Designer<br/>Scheme</h3>\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-text>\n        </ion-item>\n      </ion-col>\n      <ion-col id=\"specs-writer-guide\" (click)=\"openSpecsWriterGuide()\" \n          class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"book-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Specs<br/>Writer Guide</h3>\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-text>\n        </ion-item>\n      </ion-col>\n      <ion-col id=\"paint-calculator\" (click)=\"openPaintCalculator()\" \n          class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"calculator-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Paint<br/>Calculator</h3>\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-text>\n        </ion-item>\n      </ion-col>\n      <ion-col id=\"color-capture\" (click)=\"openColorCapture()\" \n          class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-item button mode=\"md\" lines=\"none\" class=\"col-btn ion-padding-top-8 ion-padding-bottom-8 ion-activatable ripple-parent\">\n          <ion-icon color=\"light\" name=\"camera-outline\" slot=\"start\" class=\"home-btn-icon ion-margin-start ion-padding-start\"></ion-icon>\n          <ion-text color=\"light\" slot=\"end\" class=\"\">\n            <h3 class=\"home-btn-label\">Color<br/>Capture</h3>\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-text>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/home-tab/home-tab-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/tab-pages/home-tab/home-tab-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: HomeTabPageRoutingModule */

  /***/
  function srcAppPagesTabPagesHomeTabHomeTabRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeTabPageRoutingModule", function () {
      return HomeTabPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _home_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home-tab.page */
    "./src/app/pages/tab-pages/home-tab/home-tab.page.ts");

    var routes = [{
      path: '',
      component: _home_tab_page__WEBPACK_IMPORTED_MODULE_3__["HomeTabPage"]
    }];

    var HomeTabPageRoutingModule = function HomeTabPageRoutingModule() {
      _classCallCheck(this, HomeTabPageRoutingModule);
    };

    HomeTabPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomeTabPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/home-tab/home-tab.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/tab-pages/home-tab/home-tab.module.ts ***!
    \*************************************************************/

  /*! exports provided: HomeTabPageModule */

  /***/
  function srcAppPagesTabPagesHomeTabHomeTabModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeTabPageModule", function () {
      return HomeTabPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _home_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home-tab-routing.module */
    "./src/app/pages/tab-pages/home-tab/home-tab-routing.module.ts");
    /* harmony import */


    var _home_tab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home-tab.page */
    "./src/app/pages/tab-pages/home-tab/home-tab.page.ts");

    var HomeTabPageModule = function HomeTabPageModule() {
      _classCallCheck(this, HomeTabPageModule);
    };

    HomeTabPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomeTabPageRoutingModule"]],
      declarations: [_home_tab_page__WEBPACK_IMPORTED_MODULE_6__["HomeTabPage"]]
    })], HomeTabPageModule);
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/home-tab/home-tab.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pages/tab-pages/home-tab/home-tab.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTabPagesHomeTabHomeTabPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --ion-background-color: var(--app-primary-color) !important;\n  --color: #fff;\n}\n\nion-item {\n  --color: #fff;\n}\n\n#home-logo {\n  margin: auto;\n  display: block;\n  width: 80%;\n}\n\n.home-btn-label {\n  text-align: right;\n  font-weight: 600;\n  text-transform: uppercase;\n  margin-right: 0.7em;\n}\n\n#home-top-text {\n  margin-top: 0;\n  font-weight: 600;\n  color: #e2e3ea;\n}\n\n.home-span-color {\n  color: #fe1f23;\n}\n\n.home-btn-icon {\n  font-size: 2.5rem;\n  margin-right: 0;\n  margin-left: 0.4em;\n}\n\n.col-btn {\n  --border-radius: 5px;\n  padding-top: 0;\n  padding-bottom: 0;\n}\n\n#product-catalog {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#9e81f8+13,cf48ec+100 */\n  --ion-background-color: #9e81f8;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #9e81f8 13%, #cf48ec 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #9e81f8 13%,#cf48ec 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #9e81f8 13%,#cf48ec 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#9e81f8\", endColorstr=\"#cf48ec\",GradientType=1 );\n  /* IE6-9 */\n}\n\n#choose-paint {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#56be99+13,1db3cb+100 */\n  --ion-background-color: #56be99;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #56be99 13%, #1db3cb 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #56be99 13%,#1db3cb 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #56be99 13%,#1db3cb 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#56be99\", endColorstr=\"#1db3cb\",GradientType=1 );\n  /* IE6-9 */\n}\n\n#color-collections {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#3db5ea+13,662eda+100 */\n  --ion-background-color: #3db5ea;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #3db5ea 13%, #662eda 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #3db5ea 13%,#662eda 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #3db5ea 13%,#662eda 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#3db5ea\", endColorstr=\"#662eda\",GradientType=1 );\n  /* IE6-9 */\n}\n\n#designer-scheme {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#d25fee+13,f1428f+100 */\n  --ion-background-color: #d25fee;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #d25fee 13%, #f1428f 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #d25fee 13%,#f1428f 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #d25fee 13%,#f1428f 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#d25fee\", endColorstr=\"#f1428f\",GradientType=1 );\n  /* IE6-9 */\n}\n\n#specs-writer-guide {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#f5c549+13,ed6b31+100 */\n  --ion-background-color: #f5c549;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #f5c549 13%, #ed6b31 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #f5c549 13%,#ed6b31 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #f5c549 13%,#ed6b31 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#f5c549\", endColorstr=\"#ed6b31\",GradientType=1 );\n  /* IE6-9 */\n}\n\n#paint-calculator {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#f95657+14,e2194d+100 */\n  --ion-background-color: #f95657;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #f95657 14%, #e2194d 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #f95657 14%,#e2194d 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #f95657 14%,#e2194d 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#f95657\", endColorstr=\"#e2194d\",GradientType=1 );\n  /* IE6-9 */\n}\n\n#color-capture {\n  /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#1fc7ad+14,2fb73b+100 */\n  --ion-background-color: #1fc7ad;\n  /* Old browsers */\n  --ion-background-color: -moz-linear-gradient(left, #1fc7ad 14%, #2fb73b 100%);\n  /* FF3.6-15 */\n  --ion-background-color: -webkit-linear-gradient(left, #1fc7ad 14%,#2fb73b 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --ion-background-color: linear-gradient(to right, #1fc7ad 14%,#2fb73b 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#1fc7ad\", endColorstr=\"#2fb73b\",GradientType=1 );\n  /* IE6-9 */\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFiLXBhZ2VzL2hvbWUtdGFiL0Y6XFxtZWxpb2Rhc1xcaW9uaWNcXHJhaW4tb3Itc2hpbmUvc3JjXFxhcHBcXHBhZ2VzXFx0YWItcGFnZXNcXGhvbWUtdGFiXFxob21lLXRhYi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3RhYi1wYWdlcy9ob21lLXRhYi9ob21lLXRhYi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwyREFBQTtFQUNBLGFBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsVUFBQTtBQ0NKOztBREVBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7QUNDSjs7QURFQTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxvQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREdBO0VBQ0ksa0hBQUE7RUFDQSwrQkFBQTtFQUFpQyxpQkFBQTtFQUNqQyw2RUFBQTtFQUFnRixhQUFBO0VBQ2hGLCtFQUFBO0VBQWtGLDRCQUFBO0VBQ2xGLDJFQUFBO0VBQThFLHFEQUFBO0VBQzlFLG1IQUFBO0VBQXFILFVBQUE7QUNLekg7O0FERkE7RUFDSSxrSEFBQTtFQUNBLCtCQUFBO0VBQWlDLGlCQUFBO0VBQ2pDLDZFQUFBO0VBQWdGLGFBQUE7RUFDaEYsK0VBQUE7RUFBa0YsNEJBQUE7RUFDbEYsMkVBQUE7RUFBOEUscURBQUE7RUFDOUUsbUhBQUE7RUFBcUgsVUFBQTtBQ1V6SDs7QUROQTtFQUNJLGtIQUFBO0VBQ0EsK0JBQUE7RUFBaUMsaUJBQUE7RUFDakMsNkVBQUE7RUFBZ0YsYUFBQTtFQUNoRiwrRUFBQTtFQUFrRiw0QkFBQTtFQUNsRiwyRUFBQTtFQUE4RSxxREFBQTtFQUM5RSxtSEFBQTtFQUFxSCxVQUFBO0FDY3pIOztBRFhBO0VBQ0ksa0hBQUE7RUFDQSwrQkFBQTtFQUFpQyxpQkFBQTtFQUNqQyw2RUFBQTtFQUFnRixhQUFBO0VBQ2hGLCtFQUFBO0VBQWtGLDRCQUFBO0VBQ2xGLDJFQUFBO0VBQThFLHFEQUFBO0VBQzlFLG1IQUFBO0VBQXFILFVBQUE7QUNtQnpIOztBRGZBO0VBQ0ksa0hBQUE7RUFDQSwrQkFBQTtFQUFpQyxpQkFBQTtFQUNqQyw2RUFBQTtFQUFnRixhQUFBO0VBQ2hGLCtFQUFBO0VBQWtGLDRCQUFBO0VBQ2xGLDJFQUFBO0VBQThFLHFEQUFBO0VBQzlFLG1IQUFBO0VBQXFILFVBQUE7QUN1QnpIOztBRG5CQTtFQUNJLGtIQUFBO0VBQ0EsK0JBQUE7RUFBaUMsaUJBQUE7RUFDakMsNkVBQUE7RUFBZ0YsYUFBQTtFQUNoRiwrRUFBQTtFQUFrRiw0QkFBQTtFQUNsRiwyRUFBQTtFQUE4RSxxREFBQTtFQUM5RSxtSEFBQTtFQUFxSCxVQUFBO0FDMkJ6SDs7QUR2QkE7RUFDSSxrSEFBQTtFQUNBLCtCQUFBO0VBQWlDLGlCQUFBO0VBQ2pDLDZFQUFBO0VBQWdGLGFBQUE7RUFDaEYsK0VBQUE7RUFBa0YsNEJBQUE7RUFDbEYsMkVBQUE7RUFBOEUscURBQUE7RUFDOUUsbUhBQUE7RUFBcUgsVUFBQTtBQytCekgiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90YWItcGFnZXMvaG9tZS10YWIvaG9tZS10YWIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcHAtcHJpbWFyeS1jb2xvcikgIWltcG9ydGFudDtcclxuICAgIC0tY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbmlvbi1pdGVte1xyXG4gICAgLS1jb2xvcjogI2ZmZjtcclxufVxyXG5cclxuI2hvbWUtbG9nbyB7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBkaXNwbGF5OmJsb2NrO1xyXG4gICAgd2lkdGg6IDgwJTtcclxufVxyXG5cclxuLmhvbWUtYnRuLWxhYmVse1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIG1hcmdpbi1yaWdodDogMC43ZW07XHJcbn1cclxuXHJcbiNob21lLXRvcC10ZXh0IHtcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgY29sb3I6ICNlMmUzZWE7XHJcbn1cclxuXHJcbi5ob21lLXNwYW4tY29sb3J7XHJcbiAgICBjb2xvcjogI2ZlMWYyMztcclxufVxyXG5cclxuLmhvbWUtYnRuLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAyLjVyZW07XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICBtYXJnaW4tbGVmdDogMC40ZW07XHJcbn1cclxuXHJcbi5jb2wtYnRue1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBwYWRkaW5nLXRvcDogMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG59XHJcblxyXG5cclxuI3Byb2R1Y3QtY2F0YWxvZ3tcclxuICAgIC8qIFBlcm1hbGluayAtIHVzZSB0byBlZGl0IGFuZCBzaGFyZSB0aGlzIGdyYWRpZW50OiBodHRwczovL2NvbG9yemlsbGEuY29tL2dyYWRpZW50LWVkaXRvci8jOWU4MWY4KzEzLGNmNDhlYysxMDAgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICM5ZTgxZjg7IC8qIE9sZCBicm93c2VycyAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgICM5ZTgxZjggMTMlLCAjY2Y0OGVjIDEwMCUpOyAvKiBGRjMuNi0xNSAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgICM5ZTgxZjggMTMlLCNjZjQ4ZWMgMTAwJSk7IC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICAjOWU4MWY4IDEzJSwjY2Y0OGVjIDEwMCUpOyAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cclxuICAgIGZpbHRlcjogcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCBzdGFydENvbG9yc3RyPScjOWU4MWY4JywgZW5kQ29sb3JzdHI9JyNjZjQ4ZWMnLEdyYWRpZW50VHlwZT0xICk7IC8qIElFNi05ICovXHJcbn1cclxuXHJcbiNjaG9vc2UtcGFpbnR7XHJcbiAgICAvKiBQZXJtYWxpbmsgLSB1c2UgdG8gZWRpdCBhbmQgc2hhcmUgdGhpcyBncmFkaWVudDogaHR0cHM6Ly9jb2xvcnppbGxhLmNvbS9ncmFkaWVudC1lZGl0b3IvIzU2YmU5OSsxMywxZGIzY2IrMTAwICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjNTZiZTk5OyAvKiBPbGQgYnJvd3NlcnMgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IC1tb3otbGluZWFyLWdyYWRpZW50KGxlZnQsICAjNTZiZTk5IDEzJSwgIzFkYjNjYiAxMDAlKTsgLyogRkYzLjYtMTUgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsICAjNTZiZTk5IDEzJSwjMWRiM2NiIDEwMCUpOyAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAgIzU2YmU5OSAxMyUsIzFkYjNjYiAxMDAlKTsgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXHJcbiAgICBmaWx0ZXI6IHByb2dpZDpEWEltYWdlVHJhbnNmb3JtLk1pY3Jvc29mdC5ncmFkaWVudCggc3RhcnRDb2xvcnN0cj0nIzU2YmU5OScsIGVuZENvbG9yc3RyPScjMWRiM2NiJyxHcmFkaWVudFR5cGU9MSApOyAvKiBJRTYtOSAqL1xyXG5cclxufVxyXG5cclxuI2NvbG9yLWNvbGxlY3Rpb25ze1xyXG4gICAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyMzZGI1ZWErMTMsNjYyZWRhKzEwMCAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzNkYjVlYTsgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgIzNkYjVlYSAxMyUsICM2NjJlZGEgMTAwJSk7IC8qIEZGMy42LTE1ICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgIzNkYjVlYSAxMyUsIzY2MmVkYSAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgICMzZGI1ZWEgMTMlLCM2NjJlZGEgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9JyMzZGI1ZWEnLCBlbmRDb2xvcnN0cj0nIzY2MmVkYScsR3JhZGllbnRUeXBlPTEgKTsgLyogSUU2LTkgKi9cclxufVxyXG5cclxuI2Rlc2lnbmVyLXNjaGVtZXtcclxuICAgIC8qIFBlcm1hbGluayAtIHVzZSB0byBlZGl0IGFuZCBzaGFyZSB0aGlzIGdyYWRpZW50OiBodHRwczovL2NvbG9yemlsbGEuY29tL2dyYWRpZW50LWVkaXRvci8jZDI1ZmVlKzEzLGYxNDI4ZisxMDAgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNkMjVmZWU7IC8qIE9sZCBicm93c2VycyAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgICNkMjVmZWUgMTMlLCAjZjE0MjhmIDEwMCUpOyAvKiBGRjMuNi0xNSAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgICNkMjVmZWUgMTMlLCNmMTQyOGYgMTAwJSk7IC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICAjZDI1ZmVlIDEzJSwjZjE0MjhmIDEwMCUpOyAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cclxuICAgIGZpbHRlcjogcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCBzdGFydENvbG9yc3RyPScjZDI1ZmVlJywgZW5kQ29sb3JzdHI9JyNmMTQyOGYnLEdyYWRpZW50VHlwZT0xICk7IC8qIElFNi05ICovXHJcblxyXG59XHJcblxyXG4jc3BlY3Mtd3JpdGVyLWd1aWRle1xyXG4gICAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyNmNWM1NDkrMTMsZWQ2YjMxKzEwMCAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2Y1YzU0OTsgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgI2Y1YzU0OSAxMyUsICNlZDZiMzEgMTAwJSk7IC8qIEZGMy42LTE1ICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgI2Y1YzU0OSAxMyUsI2VkNmIzMSAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgICNmNWM1NDkgMTMlLCNlZDZiMzEgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9JyNmNWM1NDknLCBlbmRDb2xvcnN0cj0nI2VkNmIzMScsR3JhZGllbnRUeXBlPTEgKTsgLyogSUU2LTkgKi9cclxuXHJcbn1cclxuXHJcbiNwYWludC1jYWxjdWxhdG9ye1xyXG4gICAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyNmOTU2NTcrMTQsZTIxOTRkKzEwMCAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2Y5NTY1NzsgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgI2Y5NTY1NyAxNCUsICNlMjE5NGQgMTAwJSk7IC8qIEZGMy42LTE1ICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgI2Y5NTY1NyAxNCUsI2UyMTk0ZCAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgICNmOTU2NTcgMTQlLCNlMjE5NGQgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9JyNmOTU2NTcnLCBlbmRDb2xvcnN0cj0nI2UyMTk0ZCcsR3JhZGllbnRUeXBlPTEgKTsgLyogSUU2LTkgKi9cclxuXHJcbn1cclxuXHJcbiNjb2xvci1jYXB0dXJle1xyXG4gICAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyMxZmM3YWQrMTQsMmZiNzNiKzEwMCAqL1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzFmYzdhZDsgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgIzFmYzdhZCAxNCUsICMyZmI3M2IgMTAwJSk7IC8qIEZGMy42LTE1ICovXHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChsZWZ0LCAgIzFmYzdhZCAxNCUsIzJmYjczYiAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgICMxZmM3YWQgMTQlLCMyZmI3M2IgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9JyMxZmM3YWQnLCBlbmRDb2xvcnN0cj0nIzJmYjczYicsR3JhZGllbnRUeXBlPTEgKTsgLyogSUU2LTkgKi9cclxuXHJcbn0iLCJpb24tY29udGVudCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHZhcigtLWFwcC1wcmltYXJ5LWNvbG9yKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiAjZmZmO1xufVxuXG5pb24taXRlbSB7XG4gIC0tY29sb3I6ICNmZmY7XG59XG5cbiNob21lLWxvZ28ge1xuICBtYXJnaW46IGF1dG87XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB3aWR0aDogODAlO1xufVxuXG4uaG9tZS1idG4tbGFiZWwge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgbWFyZ2luLXJpZ2h0OiAwLjdlbTtcbn1cblxuI2hvbWUtdG9wLXRleHQge1xuICBtYXJnaW4tdG9wOiAwO1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogI2UyZTNlYTtcbn1cblxuLmhvbWUtc3Bhbi1jb2xvciB7XG4gIGNvbG9yOiAjZmUxZjIzO1xufVxuXG4uaG9tZS1idG4taWNvbiB7XG4gIGZvbnQtc2l6ZTogMi41cmVtO1xuICBtYXJnaW4tcmlnaHQ6IDA7XG4gIG1hcmdpbi1sZWZ0OiAwLjRlbTtcbn1cblxuLmNvbC1idG4ge1xuICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbiAgcGFkZGluZy10b3A6IDA7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xufVxuXG4jcHJvZHVjdC1jYXRhbG9nIHtcbiAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyM5ZTgxZjgrMTMsY2Y0OGVjKzEwMCAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjOWU4MWY4O1xuICAvKiBPbGQgYnJvd3NlcnMgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgIzllODFmOCAxMyUsICNjZjQ4ZWMgMTAwJSk7XG4gIC8qIEZGMy42LTE1ICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsICM5ZTgxZjggMTMlLCNjZjQ4ZWMgMTAwJSk7XG4gIC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzllODFmOCAxMyUsI2NmNDhlYyAxMDAlKTtcbiAgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXG4gIGZpbHRlcjogcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCBzdGFydENvbG9yc3RyPVwiIzllODFmOFwiLCBlbmRDb2xvcnN0cj1cIiNjZjQ4ZWNcIixHcmFkaWVudFR5cGU9MSApO1xuICAvKiBJRTYtOSAqL1xufVxuXG4jY2hvb3NlLXBhaW50IHtcbiAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyM1NmJlOTkrMTMsMWRiM2NiKzEwMCAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjNTZiZTk5O1xuICAvKiBPbGQgYnJvd3NlcnMgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgIzU2YmU5OSAxMyUsICMxZGIzY2IgMTAwJSk7XG4gIC8qIEZGMy42LTE1ICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsICM1NmJlOTkgMTMlLCMxZGIzY2IgMTAwJSk7XG4gIC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU2YmU5OSAxMyUsIzFkYjNjYiAxMDAlKTtcbiAgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXG4gIGZpbHRlcjogcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCBzdGFydENvbG9yc3RyPVwiIzU2YmU5OVwiLCBlbmRDb2xvcnN0cj1cIiMxZGIzY2JcIixHcmFkaWVudFR5cGU9MSApO1xuICAvKiBJRTYtOSAqL1xufVxuXG4jY29sb3ItY29sbGVjdGlvbnMge1xuICAvKiBQZXJtYWxpbmsgLSB1c2UgdG8gZWRpdCBhbmQgc2hhcmUgdGhpcyBncmFkaWVudDogaHR0cHM6Ly9jb2xvcnppbGxhLmNvbS9ncmFkaWVudC1lZGl0b3IvIzNkYjVlYSsxMyw2NjJlZGErMTAwICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMzZGI1ZWE7XG4gIC8qIE9sZCBicm93c2VycyAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjM2RiNWVhIDEzJSwgIzY2MmVkYSAxMDAlKTtcbiAgLyogRkYzLjYtMTUgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzNkYjVlYSAxMyUsIzY2MmVkYSAxMDAlKTtcbiAgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjM2RiNWVhIDEzJSwjNjYyZWRhIDEwMCUpO1xuICAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cbiAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9XCIjM2RiNWVhXCIsIGVuZENvbG9yc3RyPVwiIzY2MmVkYVwiLEdyYWRpZW50VHlwZT0xICk7XG4gIC8qIElFNi05ICovXG59XG5cbiNkZXNpZ25lci1zY2hlbWUge1xuICAvKiBQZXJtYWxpbmsgLSB1c2UgdG8gZWRpdCBhbmQgc2hhcmUgdGhpcyBncmFkaWVudDogaHR0cHM6Ly9jb2xvcnppbGxhLmNvbS9ncmFkaWVudC1lZGl0b3IvI2QyNWZlZSsxMyxmMTQyOGYrMTAwICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNkMjVmZWU7XG4gIC8qIE9sZCBicm93c2VycyAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjZDI1ZmVlIDEzJSwgI2YxNDI4ZiAxMDAlKTtcbiAgLyogRkYzLjYtMTUgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgI2QyNWZlZSAxMyUsI2YxNDI4ZiAxMDAlKTtcbiAgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZDI1ZmVlIDEzJSwjZjE0MjhmIDEwMCUpO1xuICAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cbiAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9XCIjZDI1ZmVlXCIsIGVuZENvbG9yc3RyPVwiI2YxNDI4ZlwiLEdyYWRpZW50VHlwZT0xICk7XG4gIC8qIElFNi05ICovXG59XG5cbiNzcGVjcy13cml0ZXItZ3VpZGUge1xuICAvKiBQZXJtYWxpbmsgLSB1c2UgdG8gZWRpdCBhbmQgc2hhcmUgdGhpcyBncmFkaWVudDogaHR0cHM6Ly9jb2xvcnppbGxhLmNvbS9ncmFkaWVudC1lZGl0b3IvI2Y1YzU0OSsxMyxlZDZiMzErMTAwICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmNWM1NDk7XG4gIC8qIE9sZCBicm93c2VycyAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjZjVjNTQ5IDEzJSwgI2VkNmIzMSAxMDAlKTtcbiAgLyogRkYzLjYtMTUgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgI2Y1YzU0OSAxMyUsI2VkNmIzMSAxMDAlKTtcbiAgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZjVjNTQ5IDEzJSwjZWQ2YjMxIDEwMCUpO1xuICAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cbiAgZmlsdGVyOiBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoIHN0YXJ0Q29sb3JzdHI9XCIjZjVjNTQ5XCIsIGVuZENvbG9yc3RyPVwiI2VkNmIzMVwiLEdyYWRpZW50VHlwZT0xICk7XG4gIC8qIElFNi05ICovXG59XG5cbiNwYWludC1jYWxjdWxhdG9yIHtcbiAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHBzOi8vY29sb3J6aWxsYS5jb20vZ3JhZGllbnQtZWRpdG9yLyNmOTU2NTcrMTQsZTIxOTRkKzEwMCAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZjk1NjU3O1xuICAvKiBPbGQgYnJvd3NlcnMgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgI2Y5NTY1NyAxNCUsICNlMjE5NGQgMTAwJSk7XG4gIC8qIEZGMy42LTE1ICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsICNmOTU2NTcgMTQlLCNlMjE5NGQgMTAwJSk7XG4gIC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2Y5NTY1NyAxNCUsI2UyMTk0ZCAxMDAlKTtcbiAgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXG4gIGZpbHRlcjogcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCBzdGFydENvbG9yc3RyPVwiI2Y5NTY1N1wiLCBlbmRDb2xvcnN0cj1cIiNlMjE5NGRcIixHcmFkaWVudFR5cGU9MSApO1xuICAvKiBJRTYtOSAqL1xufVxuXG4jY29sb3ItY2FwdHVyZSB7XG4gIC8qIFBlcm1hbGluayAtIHVzZSB0byBlZGl0IGFuZCBzaGFyZSB0aGlzIGdyYWRpZW50OiBodHRwczovL2NvbG9yemlsbGEuY29tL2dyYWRpZW50LWVkaXRvci8jMWZjN2FkKzE0LDJmYjczYisxMDAgKi9cbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzFmYzdhZDtcbiAgLyogT2xkIGJyb3dzZXJzICovXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IC1tb3otbGluZWFyLWdyYWRpZW50KGxlZnQsICMxZmM3YWQgMTQlLCAjMmZiNzNiIDEwMCUpO1xuICAvKiBGRjMuNi0xNSAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjMWZjN2FkIDE0JSwjMmZiNzNiIDEwMCUpO1xuICAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMxZmM3YWQgMTQlLCMyZmI3M2IgMTAwJSk7XG4gIC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xuICBmaWx0ZXI6IHByb2dpZDpEWEltYWdlVHJhbnNmb3JtLk1pY3Jvc29mdC5ncmFkaWVudCggc3RhcnRDb2xvcnN0cj1cIiMxZmM3YWRcIiwgZW5kQ29sb3JzdHI9XCIjMmZiNzNiXCIsR3JhZGllbnRUeXBlPTEgKTtcbiAgLyogSUU2LTkgKi9cbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/home-tab/home-tab.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/tab-pages/home-tab/home-tab.page.ts ***!
    \***********************************************************/

  /*! exports provided: HomeTabPage */

  /***/
  function srcAppPagesTabPagesHomeTabHomeTabPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeTabPage", function () {
      return HomeTabPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var HomeTabPage = /*#__PURE__*/function () {
      function HomeTabPage(router) {
        _classCallCheck(this, HomeTabPage);

        this.router = router;
      }

      _createClass(HomeTabPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "openProductCatalog",
        value: function openProductCatalog() {
          this.router.navigate(['product-catalog']);
        }
      }, {
        key: "openChoosePaint",
        value: function openChoosePaint() {
          this.router.navigate(['product-catalog']);
        }
      }, {
        key: "openColorCollections",
        value: function openColorCollections() {
          this.router.navigate(['product-catalog']);
        }
      }, {
        key: "openDesignerScheme",
        value: function openDesignerScheme() {
          this.router.navigate(['product-catalog']);
        }
      }, {
        key: "openSpecsWriterGuide",
        value: function openSpecsWriterGuide() {
          this.router.navigate(['product-catalog']);
        }
      }, {
        key: "openPaintCalculator",
        value: function openPaintCalculator() {
          this.router.navigate(['product-catalog']);
        }
      }, {
        key: "openColorCapture",
        value: function openColorCapture() {
          this.router.navigate(['product-catalog']);
        }
      }]);

      return HomeTabPage;
    }();

    HomeTabPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }];
    };

    HomeTabPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home-tab',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home-tab.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/home-tab/home-tab.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home-tab.page.scss */
      "./src/app/pages/tab-pages/home-tab/home-tab.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])], HomeTabPage);
    /***/
  }
}]);
//# sourceMappingURL=tab-pages-home-tab-home-tab-module-es5.js.map