function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-designer-scheme-designer-scheme-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/designer-scheme/designer-scheme.page.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/designer-scheme/designer-scheme.page.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesHomeDesignerSchemeDesignerSchemePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>designer-scheme</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/home/designer-scheme/designer-scheme-routing.module.ts":
  /*!******************************************************************************!*\
    !*** ./src/app/pages/home/designer-scheme/designer-scheme-routing.module.ts ***!
    \******************************************************************************/

  /*! exports provided: DesignerSchemePageRoutingModule */

  /***/
  function srcAppPagesHomeDesignerSchemeDesignerSchemeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignerSchemePageRoutingModule", function () {
      return DesignerSchemePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _designer_scheme_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./designer-scheme.page */
    "./src/app/pages/home/designer-scheme/designer-scheme.page.ts");

    var routes = [{
      path: '',
      component: _designer_scheme_page__WEBPACK_IMPORTED_MODULE_3__["DesignerSchemePage"]
    }];

    var DesignerSchemePageRoutingModule = function DesignerSchemePageRoutingModule() {
      _classCallCheck(this, DesignerSchemePageRoutingModule);
    };

    DesignerSchemePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DesignerSchemePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/home/designer-scheme/designer-scheme.module.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/pages/home/designer-scheme/designer-scheme.module.ts ***!
    \**********************************************************************/

  /*! exports provided: DesignerSchemePageModule */

  /***/
  function srcAppPagesHomeDesignerSchemeDesignerSchemeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignerSchemePageModule", function () {
      return DesignerSchemePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _designer_scheme_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./designer-scheme-routing.module */
    "./src/app/pages/home/designer-scheme/designer-scheme-routing.module.ts");
    /* harmony import */


    var _designer_scheme_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./designer-scheme.page */
    "./src/app/pages/home/designer-scheme/designer-scheme.page.ts");

    var DesignerSchemePageModule = function DesignerSchemePageModule() {
      _classCallCheck(this, DesignerSchemePageModule);
    };

    DesignerSchemePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _designer_scheme_routing_module__WEBPACK_IMPORTED_MODULE_5__["DesignerSchemePageRoutingModule"]],
      declarations: [_designer_scheme_page__WEBPACK_IMPORTED_MODULE_6__["DesignerSchemePage"]]
    })], DesignerSchemePageModule);
    /***/
  },

  /***/
  "./src/app/pages/home/designer-scheme/designer-scheme.page.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/pages/home/designer-scheme/designer-scheme.page.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesHomeDesignerSchemeDesignerSchemePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvZGVzaWduZXItc2NoZW1lL2Rlc2lnbmVyLXNjaGVtZS5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/home/designer-scheme/designer-scheme.page.ts":
  /*!********************************************************************!*\
    !*** ./src/app/pages/home/designer-scheme/designer-scheme.page.ts ***!
    \********************************************************************/

  /*! exports provided: DesignerSchemePage */

  /***/
  function srcAppPagesHomeDesignerSchemeDesignerSchemePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignerSchemePage", function () {
      return DesignerSchemePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var DesignerSchemePage = /*#__PURE__*/function () {
      function DesignerSchemePage() {
        _classCallCheck(this, DesignerSchemePage);
      }

      _createClass(DesignerSchemePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return DesignerSchemePage;
    }();

    DesignerSchemePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-designer-scheme',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./designer-scheme.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/designer-scheme/designer-scheme.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./designer-scheme.page.scss */
      "./src/app/pages/home/designer-scheme/designer-scheme.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], DesignerSchemePage);
    /***/
  }
}]);
//# sourceMappingURL=pages-home-designer-scheme-designer-scheme-module-es5.js.map