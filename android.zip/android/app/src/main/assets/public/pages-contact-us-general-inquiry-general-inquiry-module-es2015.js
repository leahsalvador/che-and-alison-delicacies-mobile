(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-contact-us-general-inquiry-general-inquiry-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contact-us/general-inquiry/general-inquiry.page.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contact-us/general-inquiry/general-inquiry.page.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>general-inquiry</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/contact-us/general-inquiry/general-inquiry-routing.module.ts":
/*!************************************************************************************!*\
  !*** ./src/app/pages/contact-us/general-inquiry/general-inquiry-routing.module.ts ***!
  \************************************************************************************/
/*! exports provided: GeneralInquiryPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneralInquiryPageRoutingModule", function() { return GeneralInquiryPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _general_inquiry_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./general-inquiry.page */ "./src/app/pages/contact-us/general-inquiry/general-inquiry.page.ts");




const routes = [
    {
        path: '',
        component: _general_inquiry_page__WEBPACK_IMPORTED_MODULE_3__["GeneralInquiryPage"]
    }
];
let GeneralInquiryPageRoutingModule = class GeneralInquiryPageRoutingModule {
};
GeneralInquiryPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], GeneralInquiryPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/contact-us/general-inquiry/general-inquiry.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/pages/contact-us/general-inquiry/general-inquiry.module.ts ***!
  \****************************************************************************/
/*! exports provided: GeneralInquiryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneralInquiryPageModule", function() { return GeneralInquiryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _general_inquiry_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./general-inquiry-routing.module */ "./src/app/pages/contact-us/general-inquiry/general-inquiry-routing.module.ts");
/* harmony import */ var _general_inquiry_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./general-inquiry.page */ "./src/app/pages/contact-us/general-inquiry/general-inquiry.page.ts");







let GeneralInquiryPageModule = class GeneralInquiryPageModule {
};
GeneralInquiryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _general_inquiry_routing_module__WEBPACK_IMPORTED_MODULE_5__["GeneralInquiryPageRoutingModule"]
        ],
        declarations: [_general_inquiry_page__WEBPACK_IMPORTED_MODULE_6__["GeneralInquiryPage"]]
    })
], GeneralInquiryPageModule);



/***/ }),

/***/ "./src/app/pages/contact-us/general-inquiry/general-inquiry.page.scss":
/*!****************************************************************************!*\
  !*** ./src/app/pages/contact-us/general-inquiry/general-inquiry.page.scss ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NvbnRhY3QtdXMvZ2VuZXJhbC1pbnF1aXJ5L2dlbmVyYWwtaW5xdWlyeS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/contact-us/general-inquiry/general-inquiry.page.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/contact-us/general-inquiry/general-inquiry.page.ts ***!
  \**************************************************************************/
/*! exports provided: GeneralInquiryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneralInquiryPage", function() { return GeneralInquiryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let GeneralInquiryPage = class GeneralInquiryPage {
    constructor() { }
    ngOnInit() {
    }
};
GeneralInquiryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-general-inquiry',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./general-inquiry.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contact-us/general-inquiry/general-inquiry.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./general-inquiry.page.scss */ "./src/app/pages/contact-us/general-inquiry/general-inquiry.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], GeneralInquiryPage);



/***/ })

}]);
//# sourceMappingURL=pages-contact-us-general-inquiry-general-inquiry-module-es2015.js.map