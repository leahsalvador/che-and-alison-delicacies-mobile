function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-contact-us-disclaimer-disclaimer-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contact-us/disclaimer/disclaimer.page.html":
  /*!********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contact-us/disclaimer/disclaimer.page.html ***!
    \********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesContactUsDisclaimerDisclaimerPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>disclaimer</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/contact-us/disclaimer/disclaimer-routing.module.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/pages/contact-us/disclaimer/disclaimer-routing.module.ts ***!
    \**************************************************************************/

  /*! exports provided: DisclaimerPageRoutingModule */

  /***/
  function srcAppPagesContactUsDisclaimerDisclaimerRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DisclaimerPageRoutingModule", function () {
      return DisclaimerPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _disclaimer_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./disclaimer.page */
    "./src/app/pages/contact-us/disclaimer/disclaimer.page.ts");

    var routes = [{
      path: '',
      component: _disclaimer_page__WEBPACK_IMPORTED_MODULE_3__["DisclaimerPage"]
    }];

    var DisclaimerPageRoutingModule = function DisclaimerPageRoutingModule() {
      _classCallCheck(this, DisclaimerPageRoutingModule);
    };

    DisclaimerPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DisclaimerPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/contact-us/disclaimer/disclaimer.module.ts":
  /*!******************************************************************!*\
    !*** ./src/app/pages/contact-us/disclaimer/disclaimer.module.ts ***!
    \******************************************************************/

  /*! exports provided: DisclaimerPageModule */

  /***/
  function srcAppPagesContactUsDisclaimerDisclaimerModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DisclaimerPageModule", function () {
      return DisclaimerPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _disclaimer_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./disclaimer-routing.module */
    "./src/app/pages/contact-us/disclaimer/disclaimer-routing.module.ts");
    /* harmony import */


    var _disclaimer_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./disclaimer.page */
    "./src/app/pages/contact-us/disclaimer/disclaimer.page.ts");

    var DisclaimerPageModule = function DisclaimerPageModule() {
      _classCallCheck(this, DisclaimerPageModule);
    };

    DisclaimerPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _disclaimer_routing_module__WEBPACK_IMPORTED_MODULE_5__["DisclaimerPageRoutingModule"]],
      declarations: [_disclaimer_page__WEBPACK_IMPORTED_MODULE_6__["DisclaimerPage"]]
    })], DisclaimerPageModule);
    /***/
  },

  /***/
  "./src/app/pages/contact-us/disclaimer/disclaimer.page.scss":
  /*!******************************************************************!*\
    !*** ./src/app/pages/contact-us/disclaimer/disclaimer.page.scss ***!
    \******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesContactUsDisclaimerDisclaimerPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NvbnRhY3QtdXMvZGlzY2xhaW1lci9kaXNjbGFpbWVyLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/contact-us/disclaimer/disclaimer.page.ts":
  /*!****************************************************************!*\
    !*** ./src/app/pages/contact-us/disclaimer/disclaimer.page.ts ***!
    \****************************************************************/

  /*! exports provided: DisclaimerPage */

  /***/
  function srcAppPagesContactUsDisclaimerDisclaimerPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DisclaimerPage", function () {
      return DisclaimerPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var DisclaimerPage = /*#__PURE__*/function () {
      function DisclaimerPage() {
        _classCallCheck(this, DisclaimerPage);
      }

      _createClass(DisclaimerPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return DisclaimerPage;
    }();

    DisclaimerPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-disclaimer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./disclaimer.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/contact-us/disclaimer/disclaimer.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./disclaimer.page.scss */
      "./src/app/pages/contact-us/disclaimer/disclaimer.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], DisclaimerPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-contact-us-disclaimer-disclaimer-module-es5.js.map