function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-pages-contact-us-tab-contact-us-tab-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.html":
  /*!***************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.html ***!
    \***************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTabPagesContactUsTabContactUsTabPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title color=\"light\" class=\"ion-text-center ion-text-uppercase\">\n      We are here to help\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n\n  <ion-grid class=\"ion-margin-top\">\n    <ion-row>\n      <ion-col class=\"ion-padding-start ion-padding-end ion-margin-bottom\" size=\"12\">\n        <ion-card class=\"ion-activatable ripple-parent ion-no-margin ion-padding-top-4 ion-padding-bottom-4 col-btn\">\n          <ion-row>\n            <ion-col size=\"2\">\n              <ion-icon class=\"card-icon\" name=\"brush-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"10\" class=\"ion-padding-end\">\n              <ion-text>\n                <h3 class=\"card-title\">Professional Painting Service</h3>\n              </ion-text>\n              <p class=\"card-description\">\n                (632) 682 8888 /\n                (632) 645 0807 /\n                (632) 645 8750 /\n                (632) 645 8744\n              </p>\n            </ion-col>\n          </ion-row>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-card>\n      </ion-col>\n      <ion-col class=\"ion-padding-start ion-padding-end ion-margin-bottom\" size=\"12\">\n        <ion-card class=\"ion-activatable ripple-parent ion-no-margin ion-padding-top-4 ion-padding-bottom-4 col-btn\">\n          <ion-row>\n            <ion-col size=\"2\">\n              <ion-icon class=\"card-icon\" name=\"information-circle-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"10\" class=\"ion-padding-end\">\n              <ion-text>\n                <h3 class=\"card-title\">General Inquiry</h3>\n              </ion-text>\n              <p class=\"card-description\">info@rainorshinepaint.com</p>\n            </ion-col>\n          </ion-row>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-card>\n      </ion-col>\n      <ion-col class=\"ion-padding-start ion-padding-end ion-margin-bottom\" size=\"12\">\n        <ion-card class=\"ion-activatable ripple-parent ion-no-margin ion-padding-top-4 ion-padding-bottom-4 col-btn\">\n          <ion-row>\n            <ion-col size=\"2\">\n              <ion-icon class=\"card-icon\" name=\"mail-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"10\" class=\"ion-padding-end\">\n              <ion-text>\n                <h3 class=\"card-title\">Contact Us</h3>\n              </ion-text>\n              <p class=\"card-description\">For your suggestions or feedback</p>\n            </ion-col>\n          </ion-row>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-card>\n      </ion-col>\n      <ion-col class=\"ion-padding-start ion-padding-end ion-margin-bottom\" size=\"12\">\n        <ion-card class=\"ion-activatable ripple-parent ion-no-margin ion-padding-top-4 ion-padding-bottom-4 col-btn\">\n          <ion-row>\n            <ion-col size=\"2\">\n              <ion-icon class=\"card-icon\" name=\"help-circle-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"10\" class=\"ion-padding-end\">\n              <ion-text>\n                <h3 class=\"card-title\">FAQ</h3>\n              </ion-text>\n              <p class=\"card-description\">Frequently asked questions</p>\n            </ion-col>\n          </ion-row>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-card>\n      </ion-col>\n      <ion-col class=\"ion-padding-start ion-padding-end ion-margin-bottom\" size=\"12\">\n        <ion-card class=\"ion-activatable ripple-parent ion-no-margin ion-padding-top-4 ion-padding-bottom-4 col-btn\">\n          <ion-row>\n            <ion-col size=\"2\">\n              <ion-icon class=\"card-icon\" name=\"warning-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"10\" class=\"ion-padding-end\">\n              <ion-text>\n                <h3 class=\"card-title\">Disclamer</h3>\n              </ion-text>\n              <p class=\"card-description\">Color accuracy statement</p>\n            </ion-col>\n          </ion-row>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-card>\n      </ion-col>\n      <ion-col class=\"ion-padding-start ion-padding-end ion-margin-bottom\" size=\"12\">\n        <ion-card class=\"ion-activatable ripple-parent ion-no-margin ion-padding-top-4 ion-padding-bottom-4 col-btn\">\n          <ion-row>\n            <ion-col size=\"2\">\n              <ion-icon class=\"card-icon\" name=\"document-text-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"10\" class=\"ion-padding-end\">\n              <ion-text>\n                <h3 class=\"card-title\">Policy</h3>\n              </ion-text>\n              <p class=\"card-description\">Handling of personal information</p>\n            </ion-col>\n          </ion-row>\n          <ion-ripple-effect></ion-ripple-effect>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab-routing.module.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/pages/tab-pages/contact-us-tab/contact-us-tab-routing.module.ts ***!
    \*********************************************************************************/

  /*! exports provided: ContactUsTabPageRoutingModule */

  /***/
  function srcAppPagesTabPagesContactUsTabContactUsTabRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ContactUsTabPageRoutingModule", function () {
      return ContactUsTabPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _contact_us_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./contact-us-tab.page */
    "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.ts");

    var routes = [{
      path: '',
      component: _contact_us_tab_page__WEBPACK_IMPORTED_MODULE_3__["ContactUsTabPage"]
    }];

    var ContactUsTabPageRoutingModule = function ContactUsTabPageRoutingModule() {
      _classCallCheck(this, ContactUsTabPageRoutingModule);
    };

    ContactUsTabPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ContactUsTabPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.module.ts ***!
    \*************************************************************************/

  /*! exports provided: ContactUsTabPageModule */

  /***/
  function srcAppPagesTabPagesContactUsTabContactUsTabModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ContactUsTabPageModule", function () {
      return ContactUsTabPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _contact_us_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./contact-us-tab-routing.module */
    "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab-routing.module.ts");
    /* harmony import */


    var _contact_us_tab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./contact-us-tab.page */
    "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.ts");

    var ContactUsTabPageModule = function ContactUsTabPageModule() {
      _classCallCheck(this, ContactUsTabPageModule);
    };

    ContactUsTabPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _contact_us_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__["ContactUsTabPageRoutingModule"]],
      declarations: [_contact_us_tab_page__WEBPACK_IMPORTED_MODULE_6__["ContactUsTabPage"]]
    })], ContactUsTabPageModule);
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.scss":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.scss ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTabPagesContactUsTabContactUsTabPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --ion-background-color: #f3f3f3 !important;\n}\n\nion-header {\n  --ion-background-color: var(--app-primary-color);\n}\n\nion-title {\n  font-weight: 600;\n}\n\n.col-btn {\n  border-radius: 5px;\n  margin-bottom: 0;\n}\n\n.card-title {\n  font-weight: 800;\n  margin-bottom: 5px;\n  font-size: 1rem;\n  color: var(--app-primary-color);\n}\n\n.card-description {\n  margin-top: 0;\n}\n\n.card-icon {\n  color: var(--app-primary-color);\n  top: 0;\n  bottom: 0;\n  margin: auto;\n  position: absolute;\n  left: 0;\n  right: 0;\n  font-size: 1.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFiLXBhZ2VzL2NvbnRhY3QtdXMtdGFiL0Y6XFxtZWxpb2Rhc1xcaW9uaWNcXHJhaW4tb3Itc2hpbmUvc3JjXFxhcHBcXHBhZ2VzXFx0YWItcGFnZXNcXGNvbnRhY3QtdXMtdGFiXFxjb250YWN0LXVzLXRhYi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3RhYi1wYWdlcy9jb250YWN0LXVzLXRhYi9jb250YWN0LXVzLXRhYi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSwwQ0FBQTtBQ0FKOztBREdBO0VBQ0ksZ0RBQUE7QUNBSjs7QURHQTtFQUNJLGdCQUFBO0FDQUo7O0FER0E7RUFDSSxrQkFBQTtFQUNBLGdCQUFBO0FDQUo7O0FER0E7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLCtCQUFBO0FDQUo7O0FER0E7RUFDSSxhQUFBO0FDQUo7O0FER0E7RUFDSSwrQkFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxpQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGFiLXBhZ2VzL2NvbnRhY3QtdXMtdGFiL2NvbnRhY3QtdXMtdGFiLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pb24tY29udGVudHtcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmM2YzZjMgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWhlYWRlcntcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHZhcigtLWFwcC1wcmltYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuaW9uLXRpdGxle1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG5cclxuLmNvbC1idG57XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG59XHJcblxyXG4uY2FyZC10aXRsZXtcclxuICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICBmb250LXNpemU6IDFyZW07XHJcbiAgICBjb2xvcjogdmFyKC0tYXBwLXByaW1hcnktY29sb3IpO1xyXG59XHJcblxyXG4uY2FyZC1kZXNjcmlwdGlvbntcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbn1cclxuXHJcbi5jYXJkLWljb257XHJcbiAgICBjb2xvcjogdmFyKC0tYXBwLXByaW1hcnktY29sb3IpO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgZm9udC1zaXplOiAxLjVyZW07XHJcbn0iLCJpb24tY29udGVudCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmM2YzZjMgIWltcG9ydGFudDtcbn1cblxuaW9uLWhlYWRlciB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHZhcigtLWFwcC1wcmltYXJ5LWNvbG9yKTtcbn1cblxuaW9uLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cblxuLmNvbC1idG4ge1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG5cbi5jYXJkLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBmb250LXNpemU6IDFyZW07XG4gIGNvbG9yOiB2YXIoLS1hcHAtcHJpbWFyeS1jb2xvcik7XG59XG5cbi5jYXJkLWRlc2NyaXB0aW9uIHtcbiAgbWFyZ2luLXRvcDogMDtcbn1cblxuLmNhcmQtaWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1hcHAtcHJpbWFyeS1jb2xvcik7XG4gIHRvcDogMDtcbiAgYm90dG9tOiAwO1xuICBtYXJnaW46IGF1dG87XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIGZvbnQtc2l6ZTogMS41cmVtO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.ts ***!
    \***********************************************************************/

  /*! exports provided: ContactUsTabPage */

  /***/
  function srcAppPagesTabPagesContactUsTabContactUsTabPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ContactUsTabPage", function () {
      return ContactUsTabPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var ContactUsTabPage = /*#__PURE__*/function () {
      function ContactUsTabPage() {
        _classCallCheck(this, ContactUsTabPage);
      }

      _createClass(ContactUsTabPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return ContactUsTabPage;
    }();

    ContactUsTabPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-contact-us-tab',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./contact-us-tab.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./contact-us-tab.page.scss */
      "./src/app/pages/tab-pages/contact-us-tab/contact-us-tab.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], ContactUsTabPage);
    /***/
  }
}]);
//# sourceMappingURL=tab-pages-contact-us-tab-contact-us-tab-module-es5.js.map