(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-pages-about-tab-about-tab-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/about-tab/about-tab.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/about-tab/about-tab.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title color=\"light\" class=\"ion-text-center ion-text-uppercase\">\n      About Us\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">About</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-grid>\n\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-text class=\"ion-text-uppercase\">\n          <h1 class=\"about-title\">About Us</h1>\n        </ion-text>\n        <p class=\"about-text\">Rain or Shine (ROS) Elastomeric Waterproofing Paint is the flagship brand of Asian\n          Coatings Philippines\n          Incorporated. It is one of the leading paint manufacturers in the Philippines. The company started\n          manufacturing high quality house paints in1992 and with the foresight of its visionary leader, the company\n          ventured into making superior elastomeric waterproofing paint in 2004 under the brand name Rain or Shine\n          (ROS).</p>\n        <p class=\"about-text\">\n          Smartly marketing their products to their target market the company went into sports marketing. It joined\n          the Philippine Basketball Association (PBA) in 2006 and named its team RAIN OR SHINE ELASTOPAINTERS.\n        </p>\n        <p class=\"about-text\">\n          Rain or Shine (ROS) will continue its leadership in elastomeric paints by providing its consumers the\n          highest quality products and serve them with excellent sales service. We will develop new products that will\n          help our customers in providing protection and beauty to any structure because with Rain or Shine (ROS)\n          \"WE’VE GOT YOU COVERED\".</p>\n      </ion-col>\n      <ion-col class=\"ion-padding-start ion-padding-end\" size=\"12\">\n        <ion-text class=\"ion-text-uppercase\">\n          <h1 class=\"about-title\">ROS at your service</h1>\n        </ion-text>\n        <p class=\"about-text\">Rain or Shine Technical Service Representative provides on-time technical service to its customers. With a fleet\n        of technical service vehicles we are able to provide excellent service to help you with your painting project.\n        We can evaluate your paint requirements and provide you with accurate recommendation that is best suited for\n        your painting needs. We also provide paint estimate free of charge. We can do actual product sampling at the\n        jobsite and give you product orientation on thespot. We can troubleshoot any problems you may encounter with\n        regards to paints even if you used other brands.</p>\n\n        <p class=\"about-text\">We at Rain or Shine are committed to provide you a nice painting experience with our service on wheels and will\n        make sure that your project is protected against water penetration and harsh elements.</p>\n\n        <p class=\"about-text\"><span class=\"quote\">\"Don't just use any paint, with Rain or Shine you are protected.\"</span></p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/tab-pages/about-tab/about-tab-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/tab-pages/about-tab/about-tab-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: AboutTabPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutTabPageRoutingModule", function() { return AboutTabPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _about_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./about-tab.page */ "./src/app/pages/tab-pages/about-tab/about-tab.page.ts");




const routes = [
    {
        path: '',
        component: _about_tab_page__WEBPACK_IMPORTED_MODULE_3__["AboutTabPage"]
    }
];
let AboutTabPageRoutingModule = class AboutTabPageRoutingModule {
};
AboutTabPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AboutTabPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/tab-pages/about-tab/about-tab.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/tab-pages/about-tab/about-tab.module.ts ***!
  \***************************************************************/
/*! exports provided: AboutTabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutTabPageModule", function() { return AboutTabPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _about_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./about-tab-routing.module */ "./src/app/pages/tab-pages/about-tab/about-tab-routing.module.ts");
/* harmony import */ var _about_tab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./about-tab.page */ "./src/app/pages/tab-pages/about-tab/about-tab.page.ts");







let AboutTabPageModule = class AboutTabPageModule {
};
AboutTabPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _about_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__["AboutTabPageRoutingModule"]
        ],
        declarations: [_about_tab_page__WEBPACK_IMPORTED_MODULE_6__["AboutTabPage"]]
    })
], AboutTabPageModule);



/***/ }),

/***/ "./src/app/pages/tab-pages/about-tab/about-tab.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/tab-pages/about-tab/about-tab.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --ion-background-color: #f3f3f3 !important;\n}\n\nion-header {\n  --ion-background-color: var(--app-primary-color);\n}\n\nion-title {\n  font-weight: 600;\n}\n\n.about-title {\n  font-weight: 700;\n  color: var(--app-primary-color);\n}\n\n.about-text {\n  line-height: 23px;\n  color: #3c3c3c;\n}\n\n.quote {\n  font-weight: bolder;\n  font-style: italic;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFiLXBhZ2VzL2Fib3V0LXRhYi9GOlxcbWVsaW9kYXNcXGlvbmljXFxyYWluLW9yLXNoaW5lL3NyY1xcYXBwXFxwYWdlc1xcdGFiLXBhZ2VzXFxhYm91dC10YWJcXGFib3V0LXRhYi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3RhYi1wYWdlcy9hYm91dC10YWIvYWJvdXQtdGFiLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLDBDQUFBO0FDQUo7O0FER0E7RUFDSSxnREFBQTtBQ0FKOztBREdBO0VBQ0ksZ0JBQUE7QUNBSjs7QURHQTtFQUNJLGdCQUFBO0VBQ0EsK0JBQUE7QUNBSjs7QURHQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtBQ0FKOztBREdBO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGFiLXBhZ2VzL2Fib3V0LXRhYi9hYm91dC10YWIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmlvbi1jb250ZW50e1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2YzZjNmMyAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taGVhZGVye1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYXBwLXByaW1hcnktY29sb3IpO1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG59XHJcblxyXG4uYWJvdXQtdGl0bGV7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgY29sb3I6IHZhcigtLWFwcC1wcmltYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuLmFib3V0LXRleHR7XHJcbiAgICBsaW5lLWhlaWdodDogMjNweDtcclxuICAgIGNvbG9yOiAjM2MzYzNjO1xyXG59XHJcblxyXG4ucXVvdGV7XHJcbiAgICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZjNmM2YzICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1oZWFkZXIge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcHAtcHJpbWFyeS1jb2xvcik7XG59XG5cbmlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5hYm91dC10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGNvbG9yOiB2YXIoLS1hcHAtcHJpbWFyeS1jb2xvcik7XG59XG5cbi5hYm91dC10ZXh0IHtcbiAgbGluZS1oZWlnaHQ6IDIzcHg7XG4gIGNvbG9yOiAjM2MzYzNjO1xufVxuXG4ucXVvdGUge1xuICBmb250LXdlaWdodDogYm9sZGVyO1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/tab-pages/about-tab/about-tab.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/tab-pages/about-tab/about-tab.page.ts ***!
  \*************************************************************/
/*! exports provided: AboutTabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutTabPage", function() { return AboutTabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AboutTabPage = class AboutTabPage {
    constructor() { }
    ngOnInit() {
    }
};
AboutTabPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-about-tab',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./about-tab.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/about-tab/about-tab.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./about-tab.page.scss */ "./src/app/pages/tab-pages/about-tab/about-tab.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], AboutTabPage);



/***/ })

}]);
//# sourceMappingURL=tab-pages-about-tab-about-tab-module-es2015.js.map