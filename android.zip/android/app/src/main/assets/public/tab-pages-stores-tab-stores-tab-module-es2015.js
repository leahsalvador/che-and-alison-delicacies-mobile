(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-pages-stores-tab-stores-tab-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/stores-tab/stores-tab.page.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/stores-tab/stores-tab.page.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title  color=\"light\" class=\"ion-text-center ion-text-uppercase\">\n      Stores\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Store</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <app-explore-container name=\"Store page\"></app-explore-container>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/tab-pages/stores-tab/stores-tab-routing.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/tab-pages/stores-tab/stores-tab-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: StoresTabPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresTabPageRoutingModule", function() { return StoresTabPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _stores_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stores-tab.page */ "./src/app/pages/tab-pages/stores-tab/stores-tab.page.ts");




const routes = [
    {
        path: '',
        component: _stores_tab_page__WEBPACK_IMPORTED_MODULE_3__["StoresTabPage"]
    }
];
let StoresTabPageRoutingModule = class StoresTabPageRoutingModule {
};
StoresTabPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], StoresTabPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/tab-pages/stores-tab/stores-tab.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/tab-pages/stores-tab/stores-tab.module.ts ***!
  \*****************************************************************/
/*! exports provided: StoresTabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresTabPageModule", function() { return StoresTabPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _stores_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./stores-tab-routing.module */ "./src/app/pages/tab-pages/stores-tab/stores-tab-routing.module.ts");
/* harmony import */ var _stores_tab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./stores-tab.page */ "./src/app/pages/tab-pages/stores-tab/stores-tab.page.ts");







let StoresTabPageModule = class StoresTabPageModule {
};
StoresTabPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _stores_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__["StoresTabPageRoutingModule"],
        ],
        declarations: [_stores_tab_page__WEBPACK_IMPORTED_MODULE_6__["StoresTabPage"]]
    })
], StoresTabPageModule);



/***/ }),

/***/ "./src/app/pages/tab-pages/stores-tab/stores-tab.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/tab-pages/stores-tab/stores-tab.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header {\n  --ion-background-color: var(--app-primary-color);\n}\n\nion-title {\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFiLXBhZ2VzL3N0b3Jlcy10YWIvRjpcXG1lbGlvZGFzXFxpb25pY1xccmFpbi1vci1zaGluZS9zcmNcXGFwcFxccGFnZXNcXHRhYi1wYWdlc1xcc3RvcmVzLXRhYlxcc3RvcmVzLXRhYi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3RhYi1wYWdlcy9zdG9yZXMtdGFiL3N0b3Jlcy10YWIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0RBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90YWItcGFnZXMvc3RvcmVzLXRhYi9zdG9yZXMtdGFiLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJ7XHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcHAtcHJpbWFyeS1jb2xvcik7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn0iLCJpb24taGVhZGVyIHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYXBwLXByaW1hcnktY29sb3IpO1xufVxuXG5pb24tdGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/tab-pages/stores-tab/stores-tab.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/tab-pages/stores-tab/stores-tab.page.ts ***!
  \***************************************************************/
/*! exports provided: StoresTabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresTabPage", function() { return StoresTabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let StoresTabPage = class StoresTabPage {
    constructor() { }
    ngOnInit() {
    }
};
StoresTabPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-stores-tab',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./stores-tab.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab-pages/stores-tab/stores-tab.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./stores-tab.page.scss */ "./src/app/pages/tab-pages/stores-tab/stores-tab.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], StoresTabPage);



/***/ })

}]);
//# sourceMappingURL=tab-pages-stores-tab-stores-tab-module-es2015.js.map